<?php
/*
* Theme template for the search results
*/
?>

<?php get_header(); ?>

<?php hkb_get_template_part('hkb-compat', 'search'); ?>

<?php get_footer(); ?>