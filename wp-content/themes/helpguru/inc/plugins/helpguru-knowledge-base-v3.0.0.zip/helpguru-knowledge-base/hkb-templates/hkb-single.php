<?php
/*
* Theme template for single page
*/
?>
<?php get_header(); ?>

<?php hkb_get_template_part('hkb-compat', 'single'); ?>

<?php get_footer(); ?>